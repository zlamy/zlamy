public class HelloOthers {
    public static void main(String[] args) {
        System.out.println("Hi Adam");
        System.out.println("Hi Lukas");
        System.out.println("Hi Matej");
    }

}