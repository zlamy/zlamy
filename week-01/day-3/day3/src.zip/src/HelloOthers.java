public class HelloOthers {
    public static void main(String[] args) {
        System.out.println("Hi Adam" + ",Hi Lukas" + "Hi Matej");
    }
}