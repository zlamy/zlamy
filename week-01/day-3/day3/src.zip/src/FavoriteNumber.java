public class FavoriteNumber {
    public static void main(String[] args) {
        int favoriteNumber = 8;
        System.out.println("My favorite number is: " + favoriteNumber);

    }

}
