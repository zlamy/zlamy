public class IntroduceYourself {
    public static void main(String[] args) {
    String name= "Matouš";
    int vek = 26;
    double height = 1.9;
        System.out.println(name);
        System.out.println(vek);
        System.out.println(height);
    }
}