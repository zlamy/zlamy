public class DefineBasicInfo {
    public static void main(String[] args) {
    String name = "Matouš";
    int age = 26;
    int height = 85;
    boolean isMarried = false;
        System.out.println("Name: " + name);
        System.out.println("Age: " + age);
        System.out.println("Height: " + height + "m");
        System.out.println("Married: " + isMarried);
    }
}
