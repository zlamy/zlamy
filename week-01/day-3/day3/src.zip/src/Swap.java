public class Swap {
    public static void main(String[] args) {
        int a = 1263;
        int b = 526;
        int tempB = a;
        int tempA = b;
        a = tempA;
        b = tempB;
        System.out.println(a);
        System.out.println(b);
    }
}
