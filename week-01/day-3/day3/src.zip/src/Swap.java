public class Swap {
    public static void main(String[] args) {
        int a = 1263;
        int b = 526;
        int tempB = a;
        int tempA = b;
        System.out.println(tempA);
        System.out.println(tempB);
    }
}
