public class TwoNumbers {
    public static void main(String[] args) {
        int a = 13;
        int b = 22;
        double numberOneDecimal = a;
        double numberTwoDecimal = b;
        System.out.println(a+b);
        System.out.println(a-b);
        System.out.println(a*b);
        System.out.println(numberTwoDecimal/numberOneDecimal);
        System.out.println(b/a);
        System.out.println(a%b);

    }





}
