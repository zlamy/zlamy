public class PrintValues {
    public static void main(String[] args) {
        // Prints a string to the terminal window
        System.out.println("Hello, World!");

        // Prints an integer to the terminal window
        System.out.println(42);

        // Prints a floating point number to the terminal window
        System.out.println(3.141592);
    }
}